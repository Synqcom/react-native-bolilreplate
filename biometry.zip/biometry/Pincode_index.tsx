import { View, SafeAreaView, Text, ViewStyle } from 'react-native';
import { BottomSheetModal } from '@gorhom/bottom-sheet';
import { useDispatch } from 'react-redux';
import React, {
  FC,
  useState,
  useEffect,
  useMemo,
  useRef,
  useCallback,
} from 'react';

import { AppBottomSheet } from 'src/sharedComponent/AppBottomSheet';
import { BiometryErrorBottomSheetContent } from 'src/sharedComponent/Biometry/BiometryErrorBottomSheetContent';
import { Circle } from './components/Circle';
import { NumberKeyboard } from './components/NumberKeyboard';
import { ModalWarning } from './components/ModalWarning';

import { useTranslation } from 'src/hooks';
import { updateSessionThunk } from 'src/redux/auth/thunks';
import { setIsBiometryUsedThunk } from 'src/redux/security/thunks';
import {
  biometryPrompt,
  openBiometrySettings,
} from 'src/utils/helpers/functions/biometrics';
import { useAppSelector } from 'src/redux/store';
import { ErrorCode } from 'src/services/ErrorService/types';
import { setIsAppSpinnerThunk } from 'src/redux/app/thunks';

import styles from './styles';

interface IPincodeProps {
  length?: number;
  startText: string;
  stepTwoText?: string;
  error?: string;
  success?: string;
  isBiometryUsed?: boolean;
  pincodeCreationMode?: boolean;
  isForgotButtonVisible?: boolean;
  onFilledPin: (pin: string) => void;
  onForgottenCode?: () => void;
  style?: ViewStyle;
}

export const Pincode: FC<IPincodeProps> = ({
  length,
  startText,
  stepTwoText,
  error = '',
  success = '',
  isBiometryUsed = false,
  pincodeCreationMode = false,
  isForgotButtonVisible = false,
  onFilledPin,
  onForgottenCode,
  style,
}) => {
  const dispatch = useDispatch();
  const { t, lang } = useTranslation();
  const bottomSheetRef = useRef<BottomSheetModal>(null);

  const { available, biometryType } = useAppSelector(
    (state) => state.app.biometry,
  );

  // Initial pincode value
  const pincodeInitialValue = useMemo(() => {
    const array = [];

    if (length) {
      for (let i = 0; i < length; i++) {
        array.push('');
      }

      return array;
    }

    return ['', '', '', '', ''];
  }, [length]);

  const [pinCode, setPinCode] = useState<string[]>(pincodeInitialValue);

  const [stepOnePin, setStepOnePin] = useState<string>('');
  const [stepTwoPin, setStepTwoPin] = useState<string>('');

  const [stepOne, setStepOne] = useState<boolean>(false);
  const [stepTwo, setStepTwo] = useState<boolean>(false);

  const [localErrorPin, setLocalErrorPin] = useState<string>('');
  const [localSuccessPin, setLocalSuccessPin] = useState<string>('');
  const [title, setTitle] = useState<string>(startText);

  const [isDisableKeyboard, setDisableKeyboard] = useState<boolean>(false);
  const [biometryErrorCode, setBiometryErrorCode] = useState<string>('');
  const [isModalWarningVisible, setModalWarningVisible] = useState<boolean>(
    false,
  );

  const authenticateParams = useMemo(() => {
    const params = {
      promptMessage: t.loginPinCodeScreen.biometry.promptMessage,
      cancelButtonText: t.loginPinCodeScreen.biometry.cancelLabel,
      code: '',
    };

    return params;
  }, [t]);

  // Pin code handler
  useEffect(() => {
    const pincodeNotCompleted = (pin: string[]) =>
      !pin.every((num) => num !== '');

    if (pincodeNotCompleted(pinCode)) {
      return;
    }

    // Login mode
    if (!pincodeCreationMode) {
      resetComponentWithDelay(1000);
      const pin = pinCode.join('');
      onFilledPin(pin);
      return;
    }

    // Pin code creation mode
    const pin = pinCode.join('');

    // Step 1
    if (!stepOne) {
      setStepOnePin(pin);
      setStepOne(true);
      setTitle(stepTwoText || '');
      resetComponentWithDelay(300);
    } else {
      // Step 2
      setStepTwoPin(pin);
      setStepTwo(true);
    }
  }, [pinCode]); // eslint-disable-line react-hooks/exhaustive-deps

  // Pin code creation mode validator
  useEffect(() => {
    if (!stepTwo) {
      return;
    }

    // Success
    if (stepOnePin === stepTwoPin) {
      setLocalSuccessPin(t.registrationPinCodeScreen.pinCode.subtitleSuccess);
      onFilledPin(stepTwoPin);
      return;
    }

    // Error
    setLocalErrorPin(t.registrationPinCodeScreen.pinCode.subtitleError);
    setStepOne(false);
    setStepTwo(false);
    resetComponentWithDelay(1000);
    setDisableKeyboard(true);
    setTimeout(() => {
      setTitle(startText);
      setDisableKeyboard(false);
    }, 1000);
  }, [stepTwo]); // eslint-disable-line react-hooks/exhaustive-deps

  const resetComponentWithDelay = useCallback(
    async (value: number) => {
      setDisableKeyboard(true);
      setTimeout(() => {
        setPinCode(pincodeInitialValue);
        setLocalErrorPin('');
        setLocalSuccessPin('');
        setDisableKeyboard(false);
      }, value);
    },
    [pincodeInitialValue],
  );

  // Error handler
  useEffect(() => {
    if (error) {
      setLocalErrorPin(error);
    }
  }, [error]);

  // Local error handler
  useEffect(() => {
    if (localErrorPin) {
      setTitle(localErrorPin);
      resetComponentWithDelay(1000);
    }
  }, [localErrorPin]); // eslint-disable-line react-hooks/exhaustive-deps

  // Success handler
  useEffect(() => {
    if (success) {
      setLocalSuccessPin(success);
    }
  }, [success]);

  // Local success handler
  useEffect(() => {
    if (localSuccessPin) {
      setTitle(localSuccessPin);
    }
  }, [localSuccessPin]);

  useEffect(() => {
    const checkBiometry = async () => {
      if (isBiometryUsed) {
        const { successPrompt, errorPrompt } = await biometryPrompt(
          authenticateParams,
        );
        if (successPrompt) {
          dispatch(setIsAppSpinnerThunk(true));
          setLocalSuccessPin('Успех');
          dispatch(updateSessionThunk(lang));
        }
        if (errorPrompt === ErrorCode.BiometryError_NotEnrolled) {
          dispatch(setIsBiometryUsedThunk(false));
          setModalWarningVisible(true);
        }
      }
    };

    checkBiometry();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const handleChangePincode = (num?: string) => {
    if (isDisableKeyboard) {
      return;
    }
    const copyPinCodeArr = [...pinCode];

    const lastNumIndex =
      copyPinCodeArr.findIndex((item) => !item) - (num ? 0 : 1);
    copyPinCodeArr[lastNumIndex] = num || '';

    setPinCode(copyPinCodeArr);
  };

  const showBottomSheet = (errorPrompt: string) => {
    const errors = [
      ErrorCode.BiometryError_NotEnrolled,
      ErrorCode.BiometryError_Lockout,
      ErrorCode.BiometryError_LockoutPermanent,
    ];

    if (errors.includes(errorPrompt as ErrorCode)) {
      setBiometryErrorCode(errorPrompt);
      bottomSheetRef.current?.present();
    }
  };

  const handleOpenDeviceSettings = () => {
    bottomSheetRef.current?.close();
    openBiometrySettings();
  };

  const handleBiometry = async () => {
    //вызов биометрии на главном экране при вводе цифр
    const { successPrompt, errorPrompt } = await biometryPrompt(
      authenticateParams,
    );
    if (successPrompt) {
      dispatch(updateSessionThunk(lang));
    }
    if (errorPrompt) {
      showBottomSheet(errorPrompt);
    }
  };

  const handleModalWarningClose = () => {
    setModalWarningVisible(false);
  };

  const isBiometryButtonVisible = useMemo(() => {
    return !pincodeCreationMode && isBiometryUsed && available;
  }, [pincodeCreationMode, isBiometryUsed, available]);

  return (
    <SafeAreaView style={[styles.wrapper, style]}>
      <View style={styles.titleWrapper}>
        <Text style={styles.title}>{title}</Text>
      </View>
      <View style={styles.circlesBar}>
        {pinCode.map((item, index) => (
          <Circle
            key={index}
            fill={!!item}
            error={!!localErrorPin}
            success={!!localSuccessPin}
          />
        ))}
      </View>
      <NumberKeyboard
        pinCode={pinCode}
        confirmPin={pincodeCreationMode}
        isDisableKeyboard={isDisableKeyboard}
        isForgotButtonVisible={isForgotButtonVisible}
        isBiometryButtonVisible={isBiometryButtonVisible}
        biometryType={biometryType || ''}
        onChangePincode={handleChangePincode}
        onBiometryPress={handleBiometry}
        onForgottenCode={onForgottenCode}
      />
      <AppBottomSheet ref={bottomSheetRef} isModal>
        <BiometryErrorBottomSheetContent
          errorCode={biometryErrorCode}
          onOpenDeviceSettings={handleOpenDeviceSettings}
        />
      </AppBottomSheet>
      <ModalWarning
        onClose={handleModalWarningClose}
        isModalWarningVisible={isModalWarningVisible}
      />
    </SafeAreaView>
  );
};
