import React, { FC, useState, useEffect, useRef } from 'react';
import { ScrollView } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { BottomSheetModal } from '@gorhom/bottom-sheet';

import { Line } from 'src/sharedComponent/Line';
import { ButtonsGroup, AppButton } from 'src/sharedComponent/Buttons';
import { AppBottomSheet } from 'src/sharedComponent/AppBottomSheet';
import { BiometryErrorBottomSheetContent } from 'src/sharedComponent/Biometry/BiometryErrorBottomSheetContent';
import { AppAlert } from 'src/sharedComponent/blocks/AppAlert';
import { BiometrySwitch } from '../BiometrySwitch';
import { ConfirmOperationSelect } from '../ConfirmOperationSelect';

import { ConfirmType } from 'src/models/app';
import { Biometry } from 'src/redux/app/types';
import { SubmitData } from '../..';
import {
  biometryPrompt,
  openBiometrySettings,
} from 'src/utils/helpers/functions/biometrics';
import { ErrorCode } from 'src/services/ErrorService/types';
import { useTranslation } from 'src/hooks';
import { CoreNavigatorProps } from 'src/core/Router';
import { Colors } from 'src/core/constants';

interface ISettingsFormProps {
  biometry: Biometry;
  onSubmit: (data: SubmitData) => void;
}

export const SettingsForm: FC<ISettingsFormProps> = ({
  biometry,
  onSubmit,
}) => {
  const { t } = useTranslation();
  const navigation = useNavigation<CoreNavigatorProps<'SecurityScreens'>>();
  const bottomSheetRef = useRef<BottomSheetModal>(null);
  console.log('biometry', biometry);
  //{"available": true, "biometryType": "Biometrics", "enrolled": true}
  const authenticateParams = {
    promptMessage: t.securitySettingsScreen.biometry.promptMessage,
    cancelButtonText: t.securitySettingsScreen.biometry.cancelLabel,
    code: '',
  };

  const { available, enrolled } = biometry;
  const [isBiometrySwitchOn, setBiometrySwitchOn] = useState<boolean>(
    available,
  );
  const [confirmType, setConfirmType] = useState<ConfirmType>(
    available ? ConfirmType.Biometry : ConfirmType.Sms,
  );
  const [errorCode, setErrorCode] = useState<string>(
    enrolled ? '' : ErrorCode.BiometryError_NotEnrolled,
  );

  useEffect(() => {
    setBiometrySwitchOn(enrolled);
    setConfirmType(enrolled ? ConfirmType.Biometry : ConfirmType.Sms);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const toggleBiometrySwitch = () => {
    if (!isBiometrySwitchOn && !enrolled) {
      setErrorCode(ErrorCode.BiometryError_NotEnrolled);
      bottomSheetRef.current?.present();
      return;
    }
    setBiometrySwitchOn(!isBiometrySwitchOn);
  };

  const handleSetConfirmValue = (code: ConfirmType) => {
    // biometry
    if (!enrolled && code === ConfirmType.Biometry) {
      setErrorCode(ErrorCode.BiometryError_NotEnrolled);
      bottomSheetRef.current?.present();
      return;
    }

    setConfirmType(code);
  };

  const handleShowOffer = () => {
    navigation.navigate('SecurityScreens', {
      screen: 'SecurityOfferScreen',
    });
  };

  const handleOpenDeviceSettings = () => {
    bottomSheetRef.current?.close();
    openBiometrySettings();
  };

  const showBottomSheet = (error: string) => {
    const errors = [
      ErrorCode.BiometryError_NotEnrolled,
      ErrorCode.BiometryError_Lockout,
      ErrorCode.BiometryError_LockoutPermanent,
    ];

    if (errors.includes(error as ErrorCode)) {
      setErrorCode(error);
      bottomSheetRef.current?.present();
    }
  };

  const handleSubmit = async () => {
    const submitData = {
      enterWithBiometry: isBiometrySwitchOn,
      confirmType,
    };

    // biometry
    if (isBiometrySwitchOn || confirmType === ConfirmType.Biometry) {
      console.log('authenticateParams1', authenticateParams);
      //выскочило окно с пальцем на проверку, но еще не пришел ответ от пальца
      const { successPrompt, errorPrompt } = await biometryPrompt(
        authenticateParams,
      );
      console.log('successPrompt', successPrompt);
      //возвращается true после успешной авторизации пальцем
      console.log('errorPrompt', errorPrompt);
      //возвращается undefined после успешной авторизации пальцем
      if (errorPrompt) {
        //сюда не заходит
        console.log('errorPrompt1', errorPrompt);
        showBottomSheet(errorPrompt);
      }
      if (!successPrompt) {
        //сюда не заходит
        console.log('successPrompt1', successPrompt);
        return;
      }
      console.log(2);
    }
    console.log('submitData', submitData);
    // submitData {"confirmType": "DIGSIGN:SHA256withRSA", "enterWithBiometry": true}
    //enterWithBiometry - флаг согласия пользователя на вход по биометрии
    //confirmType - константа
    onSubmit(submitData);
  };

  return (
    <>
      <ScrollView>
        {available && (
          <>
            <BiometrySwitch
              title={t.securitySettingsScreen.biometrySwitchTitle}
              value={isBiometrySwitchOn}
              biometricsType={biometry.biometryType}
              onChange={toggleBiometrySwitch}
            />
            <Line />
          </>
        )}
        <ConfirmOperationSelect
          title={t.securitySettingsScreen.confirmOperationTitle}
          confirmType={confirmType}
          isBiometryAvailable={available}
          onSetValue={handleSetConfirmValue}
        />
        {confirmType === ConfirmType.None && (
          <AppAlert
            text={t.securitySettingsScreen.settingsAlert.text}
            linkText={t.securitySettingsScreen.settingsAlert.linkOfferText}
            iconColor={Colors.ERROR}
            onPress={handleShowOffer}
          />
        )}
      </ScrollView>
      <ButtonsGroup>
        <AppButton
          title={t.securitySettingsScreen.saveButtonText}
          onPress={handleSubmit}
        />
      </ButtonsGroup>
      <AppBottomSheet ref={bottomSheetRef} isModal>
        <BiometryErrorBottomSheetContent
          errorCode={errorCode}
          onOpenDeviceSettings={handleOpenDeviceSettings}
        />
      </AppBottomSheet>
    </>
  );
};
