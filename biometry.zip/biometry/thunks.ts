import { SecurityResult } from './types';
import {
  setIsBiometryUsed,
  setIsSecurityPassed,
  setIsPinCodePassed,
} from './actions';
import { clientsMobileAPI } from 'src/services/api/clientsMobile';
import {
  EUpdateSecureSettingsResponse,
  UpdateSecureSettingsProps,
} from 'src/services/api/clientsMobile/types';
import { updateSessionThunk } from 'src/redux/auth/thunks';
import { asyncStorage } from 'src/utils/adapters';
import { createBiometryKeys } from 'src/utils/helpers/functions/biometrics';
import { errorService, AppError } from 'src/services/ErrorService';
import { ConfirmType } from 'src/models/app';
import { setIsAppSpinnerThunk } from 'src/redux/app/thunks';

export const setIsBiometryUsedThunk = (
  isBiometryUsed: boolean,
  showAppSpinner: boolean = true,
): SecurityResult => async (dispatch) => {
  try {
    if (showAppSpinner) {
      await dispatch(setIsAppSpinnerThunk(true));
    }

    await asyncStorage.setBooleanItem('isBiometryUsed', isBiometryUsed);
    dispatch(setIsBiometryUsed(isBiometryUsed));
  } catch (error) {
    errorService.handleErrorAsync({
      error: new AppError(error),
    });
  } finally {
    if (showAppSpinner) {
      await dispatch(setIsAppSpinnerThunk(false));
    }
  }
};

export const getIsBiometryUsedThunk = (): SecurityResult => async (
  dispatch,
) => {
  try {
    const isBiometryUsed = await asyncStorage.getBooleanItem('isBiometryUsed');
    dispatch(setIsBiometryUsed(isBiometryUsed));
  } catch (error) {
    errorService.handleErrorAsync({
      error: new AppError(error),
    });
  }
};

export const setIsSecurityPassedThunk = (
  isSecurityPassed: boolean,
): SecurityResult => async (dispatch) => {
  try {
    await asyncStorage.setBooleanItem('isSecurityPassed', isSecurityPassed);
    dispatch(setIsSecurityPassed(isSecurityPassed));
  } catch (error) {
    errorService.handleErrorAsync({
      error: new AppError(error),
    });
  }
};

export const getIsSecurityPassedThunk = (): SecurityResult => async (
  dispatch,
) => {
  try {
    const isBiometryUsed = await asyncStorage.getBooleanItem(
      'isSecurityPassed',
    );
    dispatch(setIsSecurityPassed(isBiometryUsed));
  } catch (error) {
    errorService.handleErrorAsync({
      error: new AppError(error),
    });
  }
};

export const setIsPinCodePassedThunk = (
  isPinCodePassed: boolean,
): SecurityResult => async (dispatch) => {
  try {
    await asyncStorage.setBooleanItem('isPinCodePassed', isPinCodePassed);
    dispatch(setIsPinCodePassed(isPinCodePassed));
  } catch (error) {
    errorService.handleErrorAsync({
      error: new AppError(error),
    });
  }
};

export const getIsPinCodePassedThunk = (): SecurityResult => async (
  dispatch,
) => {
  try {
    const isPinCodePassed = await asyncStorage.getBooleanItem(
      'isPinCodePassed',
    );
    dispatch(setIsPinCodePassed(isPinCodePassed));
  } catch (error) {
    errorService.handleErrorAsync({
      error: new AppError(error),
    });
  }
};

export const updateSecuritySettingsThunk = (
  type: ConfirmType,
  Lng: string,
  options?: string,
): SecurityResult => async (dispatch) => {
  try {
    await dispatch(updateSessionThunk(Lng));
    console.log('updateSecuritySettingsThunk', updateSecuritySettingsThunk);
    const config: UpdateSecureSettingsProps = {
      enabled: false,
      type: ConfirmType.None,
      verifyData: '',
    };

    switch (type) {
      case ConfirmType.Biometry:
        const publicKey = await createBiometryKeys();
        console.log('publicKeyupdateSecuritySettingsThunk', publicKey);
        // MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtHr8J9QSX+Qr/OSJwZWazVuZ4+CPe02hur/VTDducz1Z2ZKqreJheAYwpo68XcRHpcjMm/NPhYnetvSsCw5rA4pM4J5GkFkWAC7K90qsG+cAmG5ktU9NtRXG8Wq8jMw1QI/mxBZfdBz6UJgKS+n2hJn2gs3M/p4q3A/xza0cH0h49CTQmKDG1CBRK2h5iGiQ1g7QBJXIzZ3kjtoSP0xThEmAIztPpFjnWot4vATDSN9kNLvWVXw8h5WQnqflEhdFLSxqARHNtysgCzrdw9RMtD6v8L1UJqnfonZjCjaR4ZRq4ScJoAj6713TkKgfpB8
        config.type = ConfirmType.Biometry;
        config.enabled = true;
        config.verifyData = publicKey;
        break;
      case ConfirmType.Sms:
        const data = await clientsMobileAPI.getUserProfile();
        const { phone } = data;
        config.type = ConfirmType.Sms;
        config.enabled = true;
        config.address = phone;
        break;
      case ConfirmType.Password:
        config.type = ConfirmType.Password;
        config.enabled = true;
        // if (options) {
        //   config.verifyData = options;
        // }
        break;
      case ConfirmType.None:
        break;
      default:
        break;
    }
    console.log('configupdateSecureSettings', config);
    const response = await clientsMobileAPI.updateSecureSettings(config);
    console.log('responseupdateSecureSettings', response);

    if (response === EUpdateSecureSettingsResponse.Success) {
      dispatch(setIsSecurityPassedThunk(true));
    } else {
      throw response;
    }
  } catch (error) {
    errorService.handleErrorAsync({
      error: new AppError(error),
    });
  }
};
