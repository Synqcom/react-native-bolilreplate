import React, { FC, useState, useMemo, useRef } from 'react';
import { useDispatch } from 'react-redux';
import { BottomSheetModal } from '@gorhom/bottom-sheet';
import Carousel from 'react-native-snap-carousel';

import { ScreenWrapper } from 'src/sharedComponent/ScreenWrapper';
import { AppCarousel } from 'src/sharedComponent/AppCarousel';
import { Item } from 'src/sharedComponent/AppCarousel';
import { SetColorModal } from 'src/sharedComponent/Modals/SetColorModal';
import { Icon, IconName } from 'src/sharedComponent/Icon';
import { AppBottomSheet } from 'src/sharedComponent/AppBottomSheet';
import { TopBarSecondary } from 'src/sharedComponent/Bars';
import { Tabs } from 'src/sharedComponent/Tabs';
import { ActionList } from './components/ActionList';
import { InformationList } from './components/InformationList';
import { EditCardNameModal } from './components/EditCardNameModal';
import { BottomSheetContent } from './components/BottomSheetContent';

import { useTranslation } from 'src/hooks';
import { CardsRouteProps } from 'src/core/Router/CardsScreens';
import { useAppSelector, CoreDispatch } from 'src/redux/store';
import { Card } from 'src/models/cards';
import { biometry, Colors } from 'src/core/constants';
import {
  deleteCardThunk,
  setCardsAttributesListThunk,
} from 'src/redux/cards/thunks';
import { CardsActionsTypes } from 'src/redux/cards/types';
import {
  refreshConsolidatedBalance,
  setCardsList,
  setIsFetching,
} from 'src/redux/cards/actions';
import { CoreNavigatorProps } from 'src/core/Router';
import {
  setIsAppSpinnerThunk,
  setShowSystemAlertModalThunk,
} from 'src/redux/app/thunks';
import { AppAlert } from 'src/sharedComponent/blocks/AppAlert';
import { ConfirmType } from 'src/models/app';
import {
  biometryCreateSignature,
  openBiometrySettings,
} from 'src/utils/helpers/functions';
import { ErrorCode } from 'src/services/ErrorService/types';
import { BiometryErrorBottomSheetContent } from 'src/sharedComponent/Biometry/BiometryErrorBottomSheetContent';

interface ICardsScreenProps {
  route: CardsRouteProps<'CardsMainScreen'>;
  navigation: CoreNavigatorProps<'HomeMainScreen' | 'CardsScreens'>;
}

export const CardsMainScreen: FC<ICardsScreenProps> = ({
  route,
  navigation,
}) => {
  const { t } = useTranslation();
  const dispatch = useDispatch<CoreDispatch<CardsActionsTypes>>();
  const { cardId } = route.params;
  const bottomSheetRef = useRef<BottomSheetModal>(null);
  const bottomSheetBiometryRef = useRef<BottomSheetModal>(null);
  const carouselRef = useRef<Carousel<Item>>(null);
  const promptMessage = t.cardsScreen.biometry.promptMessage;
  const cancelButtonText = t.cardsScreen.biometry.cancelLabel;
  const payload = biometry.payload;

  const { cards, isOtherDevice } = useAppSelector((state) => state.cards.data);

  const activeIndex = useMemo(() => {
    const idx = cards.findIndex((card: Card) => card.id === cardId);
    return idx === -1 ? 0 : idx;
  }, [cardId, cards]);

  const [activeCardIndex, setActiveCardIndex] = useState<number>(activeIndex);
  const [isModalSetColorOpen, setModalSetColorOpen] = useState<boolean>(false);
  const [isModalEditCardNameOpen, setModalEditCardNameOpen] = useState<boolean>(
    false,
  );
  const [biometryErrorCode, setBiometryErrorCode] = useState<string>('');

  const handleActiveCardChange = (index: number) => {
    setActiveCardIndex(index);
  };

  const handleDeleteCard = async () => {
    dispatch(setIsFetching(true));
    dispatch(setIsAppSpinnerThunk(true));

    const response = await dispatch(deleteCardThunk(cards[activeCardIndex].id));

    // without confirm
    if (response && response === 'S_OK') {
      carouselRef.current?.snapToPrev(true);

      const filteredData = cards.filter(
        (card) => card.id !== cards[activeCardIndex].id,
      );

      dispatch(
        setCardsList({
          isOtherDevice,
          cards: filteredData,
          consolidated: [],
        }),
      );
      dispatch(refreshConsolidatedBalance());

      dispatch(
        setShowSystemAlertModalThunk({
          description: t.cardsScreen.actionList.submitDeleteCardModalText,
          isSuccess: true,
        }),
      );

      setTimeout(() => {
        dispatch(setIsFetching(false));
        dispatch(setIsAppSpinnerThunk(false));
        navigation.navigate('HomeMainScreen');
      }, 4000);
    }

    if (!response || typeof response !== 'object') {
      dispatch(setIsFetching(false));
      dispatch(setIsAppSpinnerThunk(false));
      return;
    }

    // error
    if ('httpCode' in response) {
      dispatch(
        setShowSystemAlertModalThunk({
          description: response.text,
        }),
      );
      return;
    }

    // need confirmation
    if (response && typeof response === 'object' && 'type' in response) {
      // sms
      if (response.type === ConfirmType.Sms) {
        dispatch(setIsFetching(false));
        dispatch(setIsAppSpinnerThunk(false));
        navigation.navigate('CardsScreens', {
          screen: 'ConfirmSmsDeleteCardScreen',
          params: {
            cardId: cards[activeCardIndex].id,
            operation: response.operationId,
            smsLength: response.smsLength,
          },
        });
        return;
      }

      // password
      if (response.type === ConfirmType.Password) {
        dispatch(setIsFetching(false));
        dispatch(setIsAppSpinnerThunk(false));
        navigation.navigate('CardsScreens', {
          screen: 'ConfirmPasswordDeleteCardScreen',
          params: {
            cardId: cards[activeCardIndex].id,
            operation: response.operationId,
            smsLength: response.smsLength,
          },
        });
        return;
      }

      // biometry
      if (response.type === ConfirmType.Biometry) {
        dispatch(setIsFetching(false));
        dispatch(setIsAppSpinnerThunk(false));
        const biometryOptions = {
          promptMessage,
          cancelButtonText,
          payload,
          code: '',
        };
        //если включено по биометрии то удаляем карту через подтверждение по биометрии вместо
        // подтверждения кодом
        const {
          successPrompt,
          errorPrompt,
          signature,
        } = await biometryCreateSignature(biometryOptions);
        if (errorPrompt) {
          showBottomSheet(errorPrompt);
          return;
        }
        try {
          dispatch(setIsFetching(true));
          dispatch(setIsAppSpinnerThunk(true));
          if (successPrompt && signature) {
            const options = {
              operation: response.operationId,
              code: signature,
              payload,
            };
            console.log('optionsDelete', options);
            const res = await dispatch(deleteCardThunk(cardId, options));
            if (res && res === 'S_OK') {
              carouselRef.current?.snapToPrev(true);
              const filteredData = cards.filter(
                (card) => card.id !== cards[activeCardIndex].id,
              );

              dispatch(
                setCardsList({
                  isOtherDevice,
                  cards: filteredData,
                  consolidated: [],
                }),
              );
              dispatch(refreshConsolidatedBalance());

              dispatch(
                setShowSystemAlertModalThunk({
                  description:
                    t.cardsScreen.actionList.submitDeleteCardModalText,
                  isSuccess: true,
                }),
              );

              setTimeout(() => {
                dispatch(setIsFetching(false));
                dispatch(setIsAppSpinnerThunk(false));
                navigation.navigate('HomeMainScreen');
              }, 4000);
            }
          }
        } catch (error) {
          console.log(
            'Error -> CardsModule -> CardsMainScreen -> deleteCard: ',
            error,
          );
        } finally {
          dispatch(setIsFetching(false));
          dispatch(setIsAppSpinnerThunk(false));
        }
      }
    }
  };

  const showBottomSheet = (error: string) => {
    const errors = [
      ErrorCode.BiometryError_NotEnrolled,
      ErrorCode.BiometryError_Lockout,
      ErrorCode.BiometryError_LockoutPermanent,
    ];

    if (errors.includes(error as ErrorCode)) {
      setBiometryErrorCode(error);
      bottomSheetBiometryRef.current?.present();
    }
  };

  const handleCloseSetColorModalForm = () => {
    setModalSetColorOpen(false);
  };

  const handleEditCardColorPress = () => {
    bottomSheetRef.current?.close();
    setModalSetColorOpen(true);
  };

  const handleEditCardNamePress = () => {
    bottomSheetRef.current?.close();
    setModalEditCardNameOpen(true);
  };

  const handleSetColor = (color: Colors) => {
    const newAttributes = [
      { panId: cards[activeCardIndex].id, attributes: { color } },
    ];

    dispatch(setCardsAttributesListThunk(newAttributes));
  };

  const handleSetCardAsDefault = (value: boolean) => {
    const list = [...cards];
    const existDefaultCardId = list.find(
      (item) => item.deviceAttributes?.isDefault,
    )?.id;
    const newAttributes = [
      { panId: cards[activeCardIndex].id, attributes: { isDefault: value } },
    ];
    if (existDefaultCardId) {
      newAttributes.push({
        panId: existDefaultCardId,
        attributes: { isDefault: false },
      });
    }

    dispatch(setCardsAttributesListThunk(newAttributes));
  };

  const handleOpenSettingsBottomSheet = () => {
    bottomSheetRef.current?.present();
  };

  const handleOpenDeviceSettings = () => {
    bottomSheetBiometryRef.current?.close();
    openBiometrySettings();
  };

  if (cards.length === 0) {
    return null;
  }

  return (
    <ScreenWrapper>
      <TopBarSecondary
        title={t.cardsScreen.title}
        leftIcon={<Icon name={IconName.ArrowLeft} />}
        rightIcon={<Icon name={IconName.SettingOutlined} />}
        rightIconOnPress={handleOpenSettingsBottomSheet}
      />
      <AppCarousel
        ref={carouselRef}
        data={cards}
        activeIndex={activeCardIndex}
        onActiveItemChange={handleActiveCardChange}
      />
      {cards[activeCardIndex]?.prcAvailable === false ? (
        <AppAlert text={t.cardsScreen.common.appAlertNotAvailableText} />
      ) : (
        <Tabs
          titles={[
            t.cardsScreen.doubleTabs.leftTabCaption,
            t.cardsScreen.doubleTabs.rightTabCaption,
          ]}
        >
          <ActionList
            cardId={cards[activeCardIndex]?.id}
            cardType={cards[activeCardIndex]?.type}
            operCodes={cards[activeCardIndex]?.operCodes}
            onDeleteCard={handleDeleteCard}
          />
          <InformationList
            cardId={cards[activeCardIndex]?.id}
            cardType={cards[activeCardIndex]?.type}
            operCodes={cards[activeCardIndex]?.operCodes}
          />
        </Tabs>
      )}
      <AppBottomSheet ref={bottomSheetRef} isModal>
        <BottomSheetContent
          operCodes={cards[activeCardIndex]?.operCodes}
          isCardDefault={cards[activeCardIndex]?.deviceAttributes?.isDefault}
          cardColor={
            cards[activeCardIndex]?.deviceAttributes?.color || Colors.BRAND
          }
          onEditCardColor={handleEditCardColorPress}
          onEditCardName={handleEditCardNamePress}
          onEditCardDefault={handleSetCardAsDefault}
        />
      </AppBottomSheet>
      <AppBottomSheet ref={bottomSheetBiometryRef} isModal>
        <BiometryErrorBottomSheetContent
          errorCode={biometryErrorCode}
          onOpenDeviceSettings={handleOpenDeviceSettings}
        />
      </AppBottomSheet>
      {isModalSetColorOpen && (
        <SetColorModal
          title={t.cardsScreen.changeColorModal.title}
          color={
            cards[activeCardIndex]?.deviceAttributes?.color || Colors.BRAND
          }
          onClose={handleCloseSetColorModalForm}
          onSetColor={handleSetColor}
          isModalSetColorOpen={isModalSetColorOpen}
        />
      )}
      {isModalEditCardNameOpen && (
        <EditCardNameModal
          cardId={cards[activeCardIndex]?.id}
          cardName={cards[activeCardIndex]?.deviceAttributes?.name || ''}
          onClose={() => setModalEditCardNameOpen(false)}
          isModalEditCardNameOpen={true}
        />
      )}
    </ScreenWrapper>
  );
};
