import React, { FC, useState, useEffect, useRef, useLayoutEffect } from 'react';
import { useDispatch } from 'react-redux';
import { ScrollView } from 'react-native';
import { BottomSheetModal } from '@gorhom/bottom-sheet';

import { ScreenWrapper } from 'src/sharedComponent/ScreenWrapper';
import { AppList } from 'src/sharedComponent/AppList';
import { Icon, IconName } from 'src/sharedComponent/Icon';
import { TopBarSecondary } from 'src/sharedComponent/Bars';
import { Line } from 'src/sharedComponent/Line';
import { AppBottomSheet } from 'src/sharedComponent/AppBottomSheet';
import { BiometryErrorBottomSheetContent } from 'src/sharedComponent/Biometry/BiometryErrorBottomSheetContent';
import { AppAlert } from 'src/sharedComponent/blocks/AppAlert';
import { BiometrySwitch } from './components/BiometrySwitch';
import { ConfirmOperationSelect } from './components/ConfirmOperationSelect';
import { BackendSelect } from 'src/sharedComponent/BackendSelect';

import { biometry, Colors } from 'src/core/constants';
import { CoreDispatch, useAppSelector } from 'src/redux/store';
import { ConfirmType } from 'src/models/app';
import { getSecureSettings } from 'src/utils/api/clientMobile';
import { useTranslation } from 'src/hooks';
import { ErrorCode } from 'src/services/ErrorService/types';
import {
  openBiometrySettings,
  biometryPrompt,
} from 'src/utils/helpers/functions/biometrics';
import { setIsAppSpinnerThunk } from 'src/redux/app/thunks';
import {
  setIsBiometryUsedThunk,
  updateSecuritySettingsThunk,
} from 'src/redux/security/thunks';
import { CoreNavigatorProps } from 'src/core/Router';
import { SecurityActionsTypes } from 'src/redux/security/types';

interface IProfileSecurityScreenProps {
  navigation: CoreNavigatorProps<'ProfileScreens' | 'SecurityScreens'>;
}

export const ProfileSecurityScreen: FC<IProfileSecurityScreenProps> = ({
  navigation,
}) => {
  const { t, lang } = useTranslation();
  const dispatch = useDispatch<CoreDispatch<SecurityActionsTypes>>();
  const bottomSheetRef = useRef<BottomSheetModal>(null);

  const { isBiometryUsed } = useAppSelector((state) => state.security);
  const { available, enrolled, biometryType } = useAppSelector(
    (state) => state.app.biometry,
  );

  const authenticateParams = {
    promptMessage: t.securitySettingsScreen.biometry.promptMessage,
    cancelButtonText: t.securitySettingsScreen.biometry.cancelLabel,
    code: '',
  };

  const [isBiometrySwitchOn, setBiometrySwitchOn] = useState<boolean>(
    () => available && isBiometryUsed,
  );
  const [confirmType, setConfirmType] = useState<ConfirmType | null>(null);
  const [errorCode, setErrorCode] = useState<string>(
    enrolled ? '' : ErrorCode.BiometryError_NotEnrolled,
  );

  useLayoutEffect(() => {
    setBiometrySwitchOn(available && isBiometryUsed);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    dispatch(setIsAppSpinnerThunk(true));
    const getSettings = async () => {
      const data = await getSecureSettings();
      if (data) {
        const { type } = data;
        setConfirmType(type);
        dispatch(setIsAppSpinnerThunk(false));
      }
    };

    getSettings();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const toggleBiometry = async () => {
    try {
      if (!isBiometrySwitchOn) {
        const { successPrompt, errorPrompt } = await biometryPrompt(
          authenticateParams,
        );
        if (errorPrompt) {
          showBottomSheet(errorPrompt);
        }
        if (successPrompt) {
          dispatch(setIsAppSpinnerThunk(true));
          dispatch(setIsBiometryUsedThunk(true));
          setBiometrySwitchOn(!isBiometrySwitchOn);
        }
      } else {
        dispatch(setIsAppSpinnerThunk(true));
        dispatch(setIsBiometryUsedThunk(false));
        setBiometrySwitchOn(!isBiometrySwitchOn);
      }
    } finally {
      dispatch(setIsAppSpinnerThunk(false));
    }
  };

  const handleChangePassword = () => {
    navigation.navigate('ProfileScreens', {
      screen: 'ChangePasswordScreen',
    });
  };

  const handleChangePincode = () => {
    navigation.navigate('ProfileScreens', {
      screen: 'OldPincodeScreen',
    });
  };

  const handleShowOffer = () => {
    navigation.navigate('ProfileScreens', {
      screen: 'OfferScreen',
    });
  };

  const showBottomSheet = (error: string) => {
    const errors = [
      ErrorCode.BiometryError_NotEnrolled,
      ErrorCode.BiometryError_Lockout,
      ErrorCode.BiometryError_LockoutPermanent,
    ];

    if (errors.includes(error as ErrorCode)) {
      setErrorCode(error);
      bottomSheetRef.current?.present();
    }
  };

  const handleSetConfirmValue = async (code: ConfirmType) => {
    try {
      if (code === ConfirmType.Biometry) {
        //при изменении способа подтверждения операций в настройках с пароля на
        // биометрию вызываем окно проверки отпечаток пальца
        const { successPrompt, errorPrompt } = await biometryPrompt(
          authenticateParams,
        );
        if (errorPrompt) {
          showBottomSheet(errorPrompt);
        }
        //и если все хорошо, то
        if (successPrompt) {
          dispatch(setIsAppSpinnerThunk(true));
          await dispatch(updateSecuritySettingsThunk(code, lang));
          setConfirmType(code);
        }
        return;
      }

      dispatch(setIsAppSpinnerThunk(true));
      await dispatch(updateSecuritySettingsThunk(code, lang));
      setConfirmType(code);
    } finally {
      dispatch(setIsAppSpinnerThunk(false));
    }
  };

  const handleOpenDeviceSettings = () => {
    bottomSheetRef.current?.close();
    openBiometrySettings();
  };

  const handleDevices = () => {
    navigation.navigate('ProfileScreens', {
      screen: 'DevicesScreen',
    });
  };

  const handleNetworkLogs = () => {
    navigation.navigate('ProfileScreens', {
      screen: 'NetworkLogsScreen',
    });
  };

  return (
    <ScreenWrapper>
      <TopBarSecondary
        title={t.profileContentScreen.profileSecurityScreen.title}
        leftIcon={<Icon name={IconName.ArrowLeft} />}
      />
      <ScrollView>
        <AppList
          leftBigIcon={<Icon name={IconName.Key} />}
          bigIconBackgroundFill={Colors.BRAND_16}
          onPress={handleChangePassword}
        >
          <AppList.Text
            leftText={
              t.profileContentScreen.profileSecurityScreen.changePassword
            }
          />
        </AppList>
        <AppList
          leftBigIcon={<Icon name={IconName.Code} />}
          bigIconBackgroundFill={Colors.BRAND_16}
          onPress={handleChangePincode}
        >
          <AppList.Text
            leftText={
              t.profileContentScreen.profileSecurityScreen.changePincode
            }
          />
        </AppList>
        {available && (
          <BiometrySwitch
            title={
              t.profileContentScreen.profileSecurityScreen.biometrySwitchTitle
            }
            biometricsType={biometryType}
            value={isBiometrySwitchOn}
            onChange={toggleBiometry}
          />
        )}
        <Line />
        <ConfirmOperationSelect
          title={
            t.profileContentScreen.profileSecurityScreen.confirmOperationTitle
          }
          confirmType={confirmType}
          isBiometryAvailable={available}
          onSetValue={handleSetConfirmValue}
        />
        {confirmType === ConfirmType.None && (
          <AppAlert
            text={
              t.profileContentScreen.profileSecurityScreen.noConfirmAlert.text
            }
            linkText={
              t.profileContentScreen.profileSecurityScreen.noConfirmAlert
                .linkOfferText
            }
            iconColor={Colors.ERROR}
            onPress={handleShowOffer}
          />
        )}
        <Line />
        <AppList
          leftBigIcon={<Icon name={IconName.Mobile} />}
          bigIconBackgroundFill={Colors.BRAND_16}
          onPress={handleDevices}
        >
          <AppList.Text
            leftText={t.profileContentScreen.profileSecurityScreen.devicesTitle}
          />
        </AppList>
        <Line />
        <BackendSelect />
        <AppList
          leftBigIcon={<Icon name={IconName.OnlineServices} />}
          bigIconBackgroundFill={Colors.BRAND_16}
          onPress={handleNetworkLogs}
        >
          <AppList.Text
            leftText={t.profileContentScreen.profileSecurityScreen.logsTitle}
          />
        </AppList>
      </ScrollView>
      <AppBottomSheet ref={bottomSheetRef} isModal>
        <BiometryErrorBottomSheetContent
          errorCode={errorCode}
          onOpenDeviceSettings={handleOpenDeviceSettings}
        />
      </AppBottomSheet>
    </ScreenWrapper>
  );
};
